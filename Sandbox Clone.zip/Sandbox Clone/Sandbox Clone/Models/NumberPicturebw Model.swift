//
//  NumberPicturebw.swift
//  Sandbox Clone
//
//  Created by Mariia Chemerys on 17.11.2023.
//

import Foundation
import SwiftUI

struct NumberedPicturebw: Identifiable{
    
    var id: Int
    var name: String
    var imageNamebw: String
}
