//
//  Sandbox_CloneApp.swift
//  Sandbox Clone
//
//  Created by Mariia Chemerys on 16.11.2023.
//

import SwiftUI

@main
struct Sandbox_CloneApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
