//
//  NumberedPicturebwViewModel.swift
//  Sandbox Clone
//
//  Created by Mariia Chemerys on 17.11.2023.
//

import Foundation

class NumberedPicturebwViewModel{
    var numberedPicturesbw=[
    NumberedPicturebw(id: 0, name: "penguin", imageNamebw: "penguin black and white"),
    NumberedPicturebw(id: 1, name: "boat", imageNamebw: "boat black and white"),
    NumberedPicturebw(id: 2, name: "solar system", imageNamebw: "solar system black and white"),
    NumberedPicturebw(id: 3, name: "raspberry", imageNamebw: "raspberry black and white"),
    NumberedPicturebw(id: 4, name: "rocket", imageNamebw: "rocket black and white"),
    NumberedPicturebw(id: 5, name: "panda", imageNamebw: "panda black and white"),
    NumberedPicturebw(id: 6, name: "tyrannosaurus", imageNamebw: "tyrannosaurus black and white"),
    NumberedPicturebw(id: 7, name: "ufo", imageNamebw: "ufo black and white"),
    NumberedPicturebw(id: 8, name: "volcano", imageNamebw: "volcano black and white"),
    NumberedPicturebw(id: 9, name: "hedgehog", imageNamebw: "hedgehog black and white"),
    NumberedPicturebw(id: 10, name: "parrot", imageNamebw: "parrot black and white"),
    NumberedPicturebw(id: 11, name: "owl", imageNamebw: "owl black and white"),
    NumberedPicturebw(id: 12, name: "beaver", imageNamebw: "beaver black and white")
    ]
}
