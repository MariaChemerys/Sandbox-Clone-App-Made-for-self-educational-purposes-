//
//  GalleryView.swift
//  Sandbox Clone
//
//  Created by Mariia Chemerys on 16.11.2023.
//

import SwiftUI

struct GalleryView: View {
    var body: some View {
        NavigationView {
            Text("GalleryView")
        }.navigationBarBackButtonHidden()
    }
}

#Preview {
    GalleryView()
}
